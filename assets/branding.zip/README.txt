OpenLauncher Brand Assets — Concept Pack

Files:
- app_icon_android_bot.png
  Android robot mascot concept for the Android application icon.
- welcome_screen_logo_wordmark.png
  Separate OpenLauncher wordmark for the Welcome Screen (no Android mascot).
- welcome_screen_visual_reference.png
  Visual reference for the Welcome Screen layout and purple/black styling.

Brand decisions:
- App icon uses an Android bot mascot.
- Welcome Screen identity is separate and uses the OpenLauncher wordmark.
- Welcome slogan: "Your Home."
- Theme: Pure Black with purple accents/waves.

These are visual concept assets, not final production-ready adaptive icon
layers or implementation files. The Welcome Screen button/text can be
implemented natively rather than baked into the final UI image.
